// pages/itemlist/itemlist.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemlist:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      itemlist: JSON.parse(options.list),
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  removeItem:function(e){
    var i=e.currentTarget.dataset.index;
    var list = this.data.itemlist;
    list.splice(i, 1)
    this.setData({
      itemlist: list
    })
    app.globalData.totalList=list;
  }
})