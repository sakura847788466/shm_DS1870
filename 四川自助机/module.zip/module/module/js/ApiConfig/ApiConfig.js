var API = 'http://58.22.61.222:36771'

function ip() {
  return API
}