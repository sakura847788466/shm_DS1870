//应写入腾讯地图的key，并改文件名为config.js
module.exports = {
  key: "4H6BZ-ZBAHI-SDOGU-5Y5FT-AELGT-H5B3O",
}
